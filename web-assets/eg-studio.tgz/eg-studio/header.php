<?php
/**
 * Cabecera: isla flotante con mega menú de servicios, botón Diagnóstico IA y menú móvil.
 */
defined( 'ABSPATH' ) || exit;
$up   = content_url( '/uploads/2026/11/' );
$diag = home_url( '/diagnostico-ia/' );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<span id="top"></span><a class="eg-skip" href="#contenido">Saltar al contenido</a>
<div class="eg-prog" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
<header class="eg-nav"><div class="eg-bar">
<a class="eg-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="enricgomez Studio, inicio"><span class="eg-logo-clip"><?php echo eg_logo_svg(); // phpcs:ignore ?></span></a>
<nav aria-label="Principal"><ul class="eg-menu"><li class="eg-pill" aria-hidden="true"></li>
<li class="eg-has-mm"><a href="<?php echo esc_url( home_url( '/servicios/' ) ); ?>" aria-haspopup="true">Servicios</a><div class="eg-mm">
<?php foreach ( eg_servicios() as $k => $s ) : ?>
<a class="eg-mm-i" href="<?php echo esc_url( eg_servicio_url( $k ) ); ?>" style="--c:<?php echo esc_attr( $s['c'] ); ?>"><span class="eg-mm-img"><img src="<?php echo esc_url( $up . $s['img'] ); ?>" alt="" loading="lazy" width="320" height="240"></span><span class="eg-mm-t"><span class="eg-mm-mark"><?php echo eg_simbolo( $k ); // phpcs:ignore ?><b>eg</b>&nbsp;<?php echo esc_html( $s['nombre'] ); ?></span><strong><?php echo esc_html( $s['titulo'] ); ?></strong><small><?php echo esc_html( $s['precio'] ); ?></small></span></a>
<?php endforeach; ?>
</div></li>
<?php foreach ( eg_menu_links() as $l ) : ?>
<li><a href="<?php echo esc_url( $l['url'] ); ?>"<?php echo $l['dot'] ? ' style="--c:var(--eg-ia)"' : ''; ?>><?php echo $l['dot'] ? '<span class="eg-dot"></span>' . esc_html( $l['txt'] ) : '<span class="eg-ul">' . esc_html( $l['txt'] ) . '</span>'; ?></a></li>
<?php endforeach; ?>
</ul></nav>
<div class="eg-nav-r"><a class="eg-btn-x" href="<?php echo esc_url( $diag ); ?>"><span class="eg-sp" aria-hidden="true"></span>Diagnóstico IA</a><button class="eg-burger" type="button" aria-label="Menú" aria-expanded="false" aria-controls="eg-mob"><span><i></i><i></i><i></i><i></i></span></button></div>
</div></header>
<div class="eg-mob" id="eg-mob" aria-label="Menú móvil"><a href="<?php echo esc_url( home_url( '/servicios/' ) ); ?>">Servicios</a><div class="eg-ms">
<?php foreach ( eg_servicios() as $k => $s ) : ?>
<a href="<?php echo esc_url( eg_servicio_url( $k ) ); ?>" style="--c:<?php echo esc_attr( $s['c'] ); ?>"><img src="<?php echo esc_url( $up . $s['img'] ); ?>" alt="" loading="lazy" width="96" height="72"><span><span class="eg-msm"><?php echo eg_simbolo( $k ); // phpcs:ignore ?><b>eg</b>&nbsp;<?php echo esc_html( $s['nombre'] ); ?></span><small><?php echo esc_html( $s['titulo'] ); ?></small></span></a>
<?php endforeach; ?>
</div>
<?php foreach ( eg_menu_links() as $l ) : ?><a href="<?php echo esc_url( $l['url'] ); ?>"><?php echo esc_html( $l['txt'] ); ?></a><?php endforeach; ?>
<a href="<?php echo esc_url( $diag ); ?>" style="color:var(--eg-web)">Diagnóstico IA →</a></div>
<main id="contenido">
