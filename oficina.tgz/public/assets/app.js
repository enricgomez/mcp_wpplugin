/* Oficina EG · interacción del panel */
(() => {
  const boot = JSON.parse(document.getElementById('boot')?.textContent || '{}');
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
  if (!boot.csrf) return; // login / ajustes

  const $ = (s, r = document) => r.querySelector(s);
  const toast = (m, bad) => { const t = $('#toast'); t.textContent = m; t.className = 'show' + (bad ? ' bad' : ''); clearTimeout(t._h); t._h = setTimeout(() => t.className = '', 2600); };

  async function api(payload) {
    const r = await fetch('/api.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin', body: JSON.stringify({ ...payload, csrf: boot.csrf }) });
    let j = {}; try { j = await r.json(); } catch (e) {}
    if (r.status === 401) { location.href = '/'; throw new Error('Sesión caducada'); }
    if (!j.ok) throw new Error(j.error || 'Error');
    return j;
  }
  async function run(payload, { reload = true, card = null } = {}) {
    if (card) card.classList.add('busy');
    try { const j = await api(payload); toast(j.msg || 'Hecho'); if (card && payload.act === 'done') card.classList.add('gone');
      if (reload) setTimeout(() => location.reload(), card ? 650 : 250); return true; }
    catch (e) { toast(e.message, true); if (card) card.classList.remove('busy'); return false; }
  }

  let current = null, currentCard = null;
  const dTask = $('#dlg-task'), dNew = $('#dlg-new'), dPost = $('#dlg-postpone'), dVoice = $('#dlg-voice');
  const open = d => { d.showModal(); };

  function fillTask(t) {
    const f = $('#f-task');
    $('#t-title').textContent = t.titulo; $('#t-cli').textContent = t.cliente || '';
    f.estado.value = t.estado || ''; f.prioridad.value = t.prioridad || ''; f.fecha.value = t.fecha || '';
    f.espera.value = t.espera || ''; f.facturar.checked = !!t.facturar; f.importe.value = t.importe ?? '';
    f.encargo.value = ''; f.nota.value = '';
    $('#t-notion').href = t.url || '#';
    const g = $('#t-gmail'); g.hidden = !t.gmail; g.href = t.gmail || '#';
    const b = $('#t-borrador'); b.hidden = !t.borrador; $('#t-borrador-txt').textContent = t.borrador || '';
  }

  document.addEventListener('click', async e => {
    const el = e.target.closest('[data-open],[data-act],[data-new],[data-refresh],[data-days],[data-mic]');
    if (!el) return;
    const card = el.closest('.task');
    if (card) { current = JSON.parse(card.dataset.task); currentCard = card; }

    if (el.matches('[data-refresh]')) { location.href = location.pathname + (location.search.includes('v=') ? location.search.replace(/&?refresh=1/, '') + '&refresh=1' : '?refresh=1'); return; }
    if (el.matches('[data-mic]')) { dictate(el); return; }
    if (el.matches('[data-open]')) { fillTask(current); open(dTask); return; }
    if (el.matches('[data-new]')) { const f = $('#f-new'); f.reset(); if (el.dataset.cliente) f.cliente.value = el.dataset.cliente; open(dNew); setTimeout(() => f.titulo.focus(), 50); return; }
    if (el.matches('[data-days]')) {
      const v = el.dataset.days; const fecha = v === 'custom' ? dPost.querySelector('[name=fecha]').value : '';
      if (v === 'custom' && !fecha) { toast('Elige una fecha', true); return; }
      dPost.close(); run({ act: 'postpone', id: current.id, estado: current.estado, days: v === 'custom' ? 0 : +v, fecha }, { card: currentCard }); return;
    }
    const act = el.dataset.act; const f = $('#f-task');
    switch (act) {
      case 'done': run({ act: 'done', id: current.id }, { card }); break;
      case 'facturado': run({ act: 'facturado', id: current.id }, { card }); break;
      case 'postpone-menu': dPost.querySelector('[name=fecha]').value = ''; open(dPost); break;
      case 'delegate-voice': $('#v-title').textContent = current.titulo; dVoice.querySelector('textarea').value = ''; open(dVoice);
        setTimeout(() => dictate(dVoice.querySelector('[data-mic]')), 150); break;
      case 'voice-send': { const t = dVoice.querySelector('textarea').value.trim(); if (!t) { toast('Dicta o escribe la orden', true); break; }
        dVoice.close(); run({ act: 'delegate', id: current.id, texto: t }); break; }
      case 'save': dTask.close(); run({ act: 'save', id: current.id, fields: { estado: f.estado.value, prioridad: f.prioridad.value, fecha: f.fecha.value, espera: f.espera.value, facturar: f.facturar.checked, importe: f.importe.value } }); break;
      case 'delegate': { const t = f.encargo.value.trim(); if (!t) { toast('Escribe o dicta la orden', true); break; } dTask.close(); run({ act: 'delegate', id: current.id, texto: t }); break; }
      case 'note': { const t = f.nota.value.trim(); if (!t) { toast('La nota está vacía', true); break; } dTask.close(); run({ act: 'note', id: current.id, texto: t }, { reload: false }); break; }
      case 'approve-draft': dTask.close(); run({ act: 'approve-draft', id: current.id }); break;
      case 'create': case 'create-delegate': { const n = $('#f-new'); const titulo = n.titulo.value.trim(); if (!titulo) { toast('Falta qué hay que hacer', true); break; }
        dNew.close(); run({ act: 'create', titulo, cliente: n.cliente.value, fecha: n.fecha.value, prioridad: n.prioridad.value, estado: n.estado.value, delegar: act === 'create-delegate' }); break; }
    }
  });

  /* ---- dictado por voz (Web Speech API, es-ES) ---- */
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  let rec = null, recBtn = null;
  if (!SR) document.documentElement.classList.add('no-sr');
  function dictate(btn) {
    const ta = btn.parentElement.querySelector('textarea');
    if (!SR) { ta.focus(); toast('Usa el micrófono del teclado para dictar'); return; }
    if (rec) { rec.stop(); return; }
    rec = new SR(); recBtn = btn;
    rec.lang = 'es-ES'; rec.interimResults = true; rec.continuous = true;
    const base = ta.value ? ta.value.replace(/\s*$/, ' ') : '';
    let finalTxt = '';
    rec.onresult = ev => { let interim = '';
      for (let i = ev.resultIndex; i < ev.results.length; i++) { const r = ev.results[i]; if (r.isFinal) finalTxt += r[0].transcript; else interim += r[0].transcript; }
      ta.value = (base + finalTxt + interim).replace(/^\s+/, ''); };
    rec.onerror = ev => { if (ev.error === 'not-allowed') toast('Permite el micrófono para dictar', true); else if (ev.error !== 'aborted' && ev.error !== 'no-speech') toast('Dictado: ' + ev.error, true); };
    rec.onend = () => { btn.classList.remove('rec'); rec = null; if (ta.value) { ta.value = ta.value.charAt(0).toUpperCase() + ta.value.slice(1); } };
    btn.classList.add('rec'); rec.start();
  }
  document.querySelectorAll('dialog').forEach(d => d.addEventListener('close', () => { if (rec) rec.stop(); }));
})();
