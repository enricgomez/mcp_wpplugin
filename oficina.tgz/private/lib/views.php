<?php
declare(strict_types=1);

function page_head(string $title): void { ?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<meta name="theme-color" content="#18242B">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Oficina EG">
<title><?= h($title) ?> · Oficina EG</title>
<link rel="icon" href="/assets/icons/favicon.png" sizes="32x32">
<link rel="apple-touch-icon" href="/assets/icons/apple-touch-icon.png">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="stylesheet" href="/assets/app.css?v=<?= OF_VERSION ?>">
<script src="/assets/app.js?v=<?= OF_VERSION ?>" defer></script>
</head>
<body>
<?php }

function page_foot(): void { ?>
</body>
</html>
<?php }

function fecha_humana(string $d): string {
    if (!$d) return '';
    $t = today();
    if ($d === $t) return 'hoy';
    if ($d === add_days($t, 1)) return 'mañana';
    if ($d === add_days($t, -1)) return 'ayer';
    $diff = (int)round((strtotime($d) - strtotime($t)) / 86400);
    $dias = ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'];
    if ($diff < 0) return 'hace ' . (-$diff) . ' d';
    if ($diff < 7) return $dias[(int)date('w', strtotime($d))] . ' ' . date('j', strtotime($d));
    return date('j/n', strtotime($d));
}

function client_names(array $ids, array $clientes): string {
    return implode(', ', array_filter(array_map(fn($id) => $clientes[$id]['nombre'] ?? '', $ids)));
}

function task_card(array $x, array $clientes, string $ctx = ''): void {
    $late = $x['fecha'] && $x['fecha'] < today();
    $json = h(json_encode([
        'id' => $x['id'], 'titulo' => $x['titulo'], 'estado' => $x['estado'], 'prioridad' => $x['prioridad'],
        'fecha' => $x['fecha'], 'espera' => $x['espera'], 'facturar' => $x['facturar'], 'importe' => $x['importe'],
        'encargo' => $x['encargo'], 'borrador' => $x['borrador'], 'gmail' => $x['gmail'], 'url' => $x['url'],
        'cliente' => client_names($x['clientes'], $clientes), 'clienteId' => $x['clientes'][0] ?? '',
    ], JSON_UNESCAPED_UNICODE));
    $cli = client_names($x['clientes'], $clientes);
    ?>
    <article class="task<?= $x['prioridad'] === 'Alta' ? ' is-alta' : '' ?>" data-task="<?= $json ?>">
      <button class="task-main" type="button" data-open>
        <span class="task-title"><?= h($x['titulo']) ?></span>
        <span class="chips">
          <?php if ($cli): ?><span class="chip chip-cli"><?= h($cli) ?></span><?php endif; ?>
          <?php if ($x['fecha']): ?><span class="chip<?= $late ? ' chip-late' : '' ?>"><?= h(fecha_humana($x['fecha'])) ?></span><?php endif; ?>
          <?php if ($x['prioridad'] && $x['prioridad'] !== 'Media'): ?><span class="chip chip-p-<?= h(strtolower($x['prioridad'])) ?>"><?= h($x['prioridad']) ?></span><?php endif; ?>
          <?php if ($x['duracion']): ?><span class="chip chip-soft"><?= h($x['duracion']) ?></span><?php endif; ?>
          <?php if ($ctx === 'facturar' && $x['importe'] !== null): ?><span class="chip chip-money"><?= h(number_format((float)$x['importe'], 2, ',', '.')) ?> €</span><?php endif; ?>
          <?php if ($x['borrador']): ?><span class="chip chip-ia">borrador listo</span><?php endif; ?>
          <?php if ($x['negocio'] && $x['negocio'] !== 'enricgomez Studio'): ?><span class="chip chip-soft"><?= h($x['negocio']) ?></span><?php endif; ?>
        </span>
        <?php if ($ctx === 'claude' && $x['encargo']): ?><span class="task-note">«<?= h(mb_strimwidth($x['encargo'], 0, 140, '…')) ?>»</span><?php endif; ?>
      </button>
      <div class="task-acts">
        <?php if ($ctx === 'facturar'): ?>
          <button type="button" class="act act-ok" data-act="facturado" title="Marcar como facturada">Facturada</button>
        <?php else: ?>
          <button type="button" class="act act-ok" data-act="done" aria-label="Marcar como hecha">✓</button>
          <button type="button" class="act" data-act="postpone-menu" aria-label="Aplazar">⏭</button>
          <button type="button" class="act act-mic" data-act="delegate-voice" aria-label="Encargar a Claude por voz">🎙</button>
        <?php endif; ?>
      </div>
    </article>
<?php }

function section(string $id, string $title, array $items, array $clientes, string $empty, string $ctx = '', string $tone = ''): void { ?>
  <section class="block <?= h($tone) ?>" id="<?= h($id) ?>">
    <h2><?= h($title) ?> <span class="count"><?= count($items) ?></span></h2>
    <?php if (!$items): ?><p class="empty"><?= h($empty) ?></p><?php endif; ?>
    <div class="list"><?php foreach ($items as $x) task_card($x, $clientes, $ctx); ?></div>
  </section>
<?php }

function render_login(string $error = ''): void {
    page_head('Entrar'); ?>
  <main class="auth">
    <img class="auth-logo" src="/assets/logo.svg" alt="enricgomez STUDIO" width="240" height="60">
    <h1>Oficina</h1>
    <form method="post" action="/?login=1" class="card">
      <input type="hidden" name="csrf" value="<?= h(csrf()) ?>">
      <label>Contraseña<input type="password" name="password" autocomplete="current-password" required autofocus></label>
      <?php if ($error): ?><p class="err"><?= h($error) ?></p><?php endif; ?>
      <button class="btn btn-pri" type="submit">Entrar</button>
    </form>
  </main>
<?php page_foot(); }

function render_setup(string $error = '', bool $editing = false): void {
    $c = cfg();
    page_head('Configuración'); ?>
  <main class="auth">
    <img class="auth-logo" src="/assets/logo.svg" alt="enricgomez STUDIO" width="240" height="60">
    <h1><?= $editing ? 'Ajustes' : 'Configurar la oficina' ?></h1>
    <form method="post" action="/?setup=1" class="card" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= h(csrf()) ?>">
      <?php if (!$editing): ?>
        <label>Código de instalación<input name="setup_code" required inputmode="numeric"></label>
      <?php endif; ?>
      <label><?= $editing ? 'Nueva contraseña (vacío = no cambiar)' : 'Contraseña para entrar' ?>
        <input type="password" name="password" autocomplete="new-password" minlength="10" <?= $editing ? '' : 'required' ?>></label>
      <label>Token de Notion (integración «Oficina EG»)<?= !empty($c['notion_token']) ? ' · guardado, vacío = no cambiar' : '' ?>
        <input type="password" name="notion_token" placeholder="ntn_…" <?= empty($c['notion_token']) ? 'required' : '' ?>></label>
      <label>Calendario: dirección secreta en formato iCal (opcional)
        <input type="url" name="ical_url" value="<?= h($c['ical_url'] ?? '') ?>" placeholder="https://calendar.google.com/calendar/ical/…/basic.ics"></label>
      <?php if ($error): ?><p class="err"><?= h($error) ?></p><?php endif; ?>
      <button class="btn btn-pri" type="submit">Guardar</button>
      <?php if ($editing): ?><a class="btn" href="/">Volver</a><?php endif; ?>
    </form>
  </main>
<?php page_foot(); }

function render_error(string $msg): void {
    page_head('Error'); ?>
  <main class="auth"><div class="card"><h1>No se puede leer Notion</h1><p class="err"><?= h($msg) ?></p>
  <a class="btn btn-pri" href="/?refresh=1">Reintentar</a> <a class="btn" href="/?ajustes=1">Ajustes</a></div></main>
<?php page_foot(); }

function render_panel(array $data, string $view): void {
    $b = build_blocks($data);
    $cl = $data['clientes'];
    $dias = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];
    $meses = ['', 'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    $hoyTxt = $dias[(int)date('w')] . ' ' . date('j') . ' de ' . $meses[(int)date('n')];
    $totFact = array_sum(array_map(fn($x) => (float)($x['importe'] ?? 0), $b['facturar']));
    page_head('Panel'); ?>
  <header class="top">
    <div class="bar4" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
    <div class="top-in">
      <a href="/" class="brand"><img src="/assets/logo-neg.svg" alt="enricgomez STUDIO" width="150" height="38"></a>
      <div class="top-r">
        <button type="button" class="icon-btn" data-refresh aria-label="Actualizar">↻</button>
        <a class="icon-btn" href="/?ajustes=1" aria-label="Ajustes">⚙</a>
      </div>
    </div>
    <div class="top-sub"><span class="eyebrow">Oficina</span> <span class="date"><?= h($hoyTxt) ?></span>
      <span class="sync">leído <?= h(date('H:i', (int)$data['leido'])) ?></span></div>
    <div class="kpis">
      <a href="/#espera" class="kpi kpi-pink"><b><?= count($b['espera']) ?></b><span>te esperan</span></a>
      <a href="/#hoy" class="kpi"><b><?= count($b['hoy']) ?></b><span>hoy</span></a>
      <a href="/#atrasadas" class="kpi kpi-warn"><b><?= count($b['atrasadas']) ?></b><span>atrasadas</span></a>
      <a href="/?v=facturar" class="kpi"><b><?= count($b['facturar']) ?></b><span>por facturar</span></a>
    </div>
  </header>

  <main class="wrap">
  <?php if ($view === 'clientes'): ?>
    <section class="block">
      <h2>Por cliente</h2>
      <div class="clients">
      <?php
        $rows = [];
        foreach ($b['clientes'] as $cid => $items) {
            $c = $cl[$cid] ?? ['nombre' => $cid === '_' ? 'Sin cliente / interno' : '(cliente)', 'estado' => '', 'url' => ''];
            $late = count(array_filter($items, fn($x) => $x['fecha'] && $x['fecha'] < today()));
            $wait = count(array_filter($items, fn($x) => $x['estado'] === 'Esperando' || $x['espera'] === 'Cliente'));
            $mine = count(array_filter($items, fn($x) => $x['espera'] === 'Enric'));
            $next = array_values(array_filter(array_map(fn($x) => $x['fecha'], $items)));
            sort($next);
            $proj = array_values(array_filter($data['proyectos'], fn($p) => in_array($cid, $p['clientes'], true)));
            $rows[] = compact('cid', 'c', 'items', 'late', 'wait', 'mine', 'next', 'proj');
        }
        usort($rows, fn($a, $z) => [$z['mine'], $z['late'], count($z['items'])] <=> [$a['mine'], $a['late'], count($a['items'])]);
        foreach ($rows as $r): $st = $r['mine'] ? 'st-pink' : ($r['late'] ? 'st-warn' : ($r['wait'] ? 'st-wait' : 'st-ok')); ?>
        <details class="client <?= $st ?>">
          <summary>
            <span class="c-dot"></span>
            <span class="c-name"><?= h($r['c']['nombre']) ?></span>
            <span class="c-meta"><?= count($r['items']) ?> abiertas<?= $r['late'] ? ' · ' . $r['late'] . ' atrasadas' : '' ?><?= $r['wait'] ? ' · ' . $r['wait'] . ' esperando' : '' ?><?= $r['mine'] ? ' · ' . $r['mine'] . ' te esperan' : '' ?></span>
          </summary>
          <?php foreach ($r['proj'] as $p): ?>
            <p class="proj">🚀 <b><?= h($p['nombre']) ?></b><?= $p['proxima'] ? ' · ' . h($p['proxima']) : '' ?></p>
          <?php endforeach; ?>
          <div class="list"><?php foreach ($r['items'] as $x) task_card($x, $cl); ?></div>
          <button type="button" class="btn btn-sm" data-new data-cliente="<?= h($r['cid'] === '_' ? '' : $r['cid']) ?>">+ Tarea para <?= h($r['c']['nombre']) ?></button>
        </details>
      <?php endforeach; ?>
      </div>
    </section>
  <?php elseif ($view === 'facturar'): ?>
    <?php section('facturar', 'Para facturar', $b['facturar'], $cl, 'Nada pendiente de facturar. Marca «Para facturar» en una tarea para que salga aquí.', 'facturar'); ?>
    <?php if ($totFact > 0): ?><p class="total">Total pendiente: <b><?= h(number_format($totFact, 2, ',', '.')) ?> €</b> sin IVA</p><?php endif; ?>
  <?php elseif ($view === 'semana'): ?>
    <?php section('semana', 'Esta semana', $b['semana'], $cl, 'Nada previsto para esta semana.'); ?>
    <?php section('esperando', 'Esperando a otros', $b['esperando'], $cl, 'Nada en espera.', '', 'tone-wait'); ?>
    <?php section('bandeja', 'Bandeja sin fecha', $b['bandeja'], $cl, 'Bandeja vacía.', '', 'tone-soft'); ?>
  <?php else: ?>
    <?php section('espera', 'Te espera a ti', $b['espera'], $cl, 'Nada pendiente de ti.', '', 'tone-pink'); ?>
    <?php section('hoy', 'Hoy', $b['hoy'], $cl, 'Nada para hoy.'); ?>
    <?php
      $ev = ical_events(2);
      if ($ev): ?>
      <section class="block" id="agenda"><h2>Agenda</h2><ul class="agenda">
        <?php foreach ($ev as $e): ?>
          <li><span class="ag-t"><?= $e['allday'] ? 'todo el día' : h(date('H:i', $e['ts'])) ?></span>
              <span class="ag-d"><?= date('Y-m-d', $e['ts']) === today() ? 'hoy' : 'mañana' ?></span>
              <span class="ag-n"><?= h($e['titulo']) ?></span></li>
        <?php endforeach; ?></ul>
        <p class="hint">Horas de Japón.</p></section>
    <?php endif; ?>
    <?php section('atrasadas', 'Atrasadas', $b['atrasadas'], $cl, 'Nada atrasado.', '', 'tone-warn'); ?>
    <?php section('claude', 'Encargadas a Claude', $b['claude'], $cl, 'Sin encargos pendientes.', 'claude', 'tone-ia'); ?>
  <?php endif; ?>
  </main>

  <nav class="tabbar" aria-label="Secciones">
    <a href="/" class="<?= $view === 'inicio' ? 'on' : '' ?>"><span>◉</span>Inicio</a>
    <a href="/?v=semana" class="<?= $view === 'semana' ? 'on' : '' ?>"><span>▦</span>Semana</a>
    <button type="button" class="fab" data-new aria-label="Nueva tarea o encargo">＋</button>
    <a href="/?v=clientes" class="<?= $view === 'clientes' ? 'on' : '' ?>"><span>◎</span>Clientes</a>
    <a href="/?v=facturar" class="<?= $view === 'facturar' ? 'on' : '' ?>"><span>€</span>Facturar</a>
  </nav>

  <?php render_dialogs($cl); ?>
  <div id="toast" role="status" aria-live="polite"></div>
  <script type="application/json" id="boot"><?= json_encode(['csrf' => csrf(), 'today' => today()], JSON_HEX_TAG) ?></script>
<?php page_foot(); }

function render_dialogs(array $clientes): void {
    $activos = array_filter($clientes, fn($c) => $c['estado'] === 'Activo');
    uasort($activos, fn($a, $b) => strcasecmp($a['nombre'], $b['nombre']));
    $opts = '<option value="">— Sin cliente —</option>';
    foreach ($activos as $c) $opts .= '<option value="' . h($c['id']) . '">' . h($c['nombre']) . '</option>';
    ?>
  <dialog id="dlg-task" class="sheet">
    <form method="dialog" class="sheet-in" id="f-task">
      <div class="sheet-h"><h3 id="t-title"></h3><button class="x" value="cancel" aria-label="Cerrar">✕</button></div>
      <p class="t-cli" id="t-cli"></p>
      <div id="t-borrador" class="borrador" hidden>
        <h4>Borrador de respuesta preparado</h4><p id="t-borrador-txt"></p>
        <p class="hint">Si te vale, pulsa «Aprobar borrador» y lo dejo listo en tu Gmail para enviarlo.</p>
        <button type="button" class="btn btn-pri" data-act="approve-draft">Aprobar borrador</button>
      </div>
      <div class="grid2">
        <label>Estado<select name="estado"><option value="">—</option><option>Bandeja</option><option>Hoy</option><option>Esta semana</option><option>Esperando</option><option>Hecha</option></select></label>
        <label>Prioridad<select name="prioridad"><option value="">—</option><option>Alta</option><option>Media</option><option>Baja</option></select></label>
        <label>Fecha límite<input type="date" name="fecha"></label>
        <label>Espera a<select name="espera"><option value="">—</option><option>Enric</option><option>Cliente</option><option>Claude</option></select></label>
        <label class="chk"><input type="checkbox" name="facturar"> Para facturar</label>
        <label>Importe (€, sin IVA)<input type="number" step="0.01" name="importe" inputmode="decimal"></label>
      </div>
      <button type="button" class="btn" data-act="save">Guardar cambios</button>
      <hr>
      <label>Encárgaselo a Claude: escribe o dicta la orden
        <span class="voice"><textarea name="encargo" rows="3" placeholder="Ej.: contesta a la clienta que lo tendremos el viernes y prepara el cambio en staging"></textarea>
        <button type="button" class="mic" data-mic="encargo" aria-label="Dictar">🎙</button></span></label>
      <button type="button" class="btn btn-ia" data-act="delegate">Encárgaselo a Claude</button>
      <label>Añadir nota
        <span class="voice"><textarea name="nota" rows="2"></textarea>
        <button type="button" class="mic" data-mic="nota" aria-label="Dictar">🎙</button></span></label>
      <button type="button" class="btn" data-act="note">Guardar nota</button>
      <p class="links"><a id="t-notion" href="#" target="_blank" rel="noopener">Abrir en Notion</a> <a id="t-gmail" href="#" target="_blank" rel="noopener" hidden>Abrir correo</a></p>
    </form>
  </dialog>

  <dialog id="dlg-new" class="sheet">
    <form method="dialog" class="sheet-in" id="f-new">
      <div class="sheet-h"><h3>Nueva tarea o encargo</h3><button class="x" value="cancel" aria-label="Cerrar">✕</button></div>
      <label>Qué hay que hacer (dicta con 🎙 y revisa antes de guardar)
        <span class="voice"><textarea name="titulo" rows="3" required></textarea>
        <button type="button" class="mic mic-big" data-mic="titulo" aria-label="Dictar">🎙</button></span></label>
      <div class="grid2">
        <label>Cliente<select name="cliente"><?= $opts ?></select></label>
        <label>Fecha<input type="date" name="fecha"></label>
        <label>Prioridad<select name="prioridad"><option value="">—</option><option>Alta</option><option selected>Media</option><option>Baja</option></select></label>
        <label>Estado<select name="estado"><option>Bandeja</option><option>Hoy</option><option>Esta semana</option></select></label>
      </div>
      <div class="row2">
        <button type="button" class="btn" data-act="create">Guardar tarea</button>
        <button type="button" class="btn btn-ia" data-act="create-delegate">Encárgaselo a Claude</button>
      </div>
    </form>
  </dialog>

  <dialog id="dlg-postpone" class="sheet sheet-sm">
    <form method="dialog" class="sheet-in">
      <div class="sheet-h"><h3>Aplazar</h3><button class="x" value="cancel" aria-label="Cerrar">✕</button></div>
      <div class="row3">
        <button type="button" class="btn" data-days="1">Mañana</button>
        <button type="button" class="btn" data-days="3">+3 días</button>
        <button type="button" class="btn" data-days="7">+1 semana</button>
      </div>
      <label>Otra fecha<input type="date" name="fecha"></label>
      <button type="button" class="btn btn-pri" data-days="custom">Aplazar a esa fecha</button>
    </form>
  </dialog>

  <dialog id="dlg-voice" class="sheet sheet-sm">
    <form method="dialog" class="sheet-in">
      <div class="sheet-h"><h3>Encargo por voz</h3><button class="x" value="cancel" aria-label="Cerrar">✕</button></div>
      <p class="t-cli" id="v-title"></p>
      <span class="voice"><textarea name="texto" rows="4" placeholder="Habla o escribe la orden…"></textarea>
      <button type="button" class="mic mic-big" data-mic="texto" aria-label="Dictar">🎙</button></span>
      <p class="hint">Revisa el texto antes de enviarlo.</p>
      <button type="button" class="btn btn-ia" data-act="voice-send">Encárgaselo a Claude</button>
    </form>
  </dialog>
<?php }
