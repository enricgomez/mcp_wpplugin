<?php
/**
 * Pie: contacto, accesos, columnas, firma con logo que se enciende y legales.
 */
defined( 'ABSPATH' ) || exit;
$mail = 'enric@enricgomez.com';
$u    = fn( $p ) => esc_url( home_url( $p ) );
?>
</main>
<footer class="eg-footer"><div class="eg-wrap">
<div class="eg-f-top" id="contacto"><div><p class="eg-k" style="color:#7CC8F0">Contacto</p><h2 style="margin-top:1rem">¿Por dónde<br>empezamos?</h2><p class="eg-f-lead">Cuéntanos qué te quita tiempo o qué quieres vender. En una semana tienes una propuesta.</p><a class="eg-f-mail" href="mailto:<?php echo esc_attr( $mail ); ?>"><?php echo esc_html( $mail ); ?> <span aria-hidden="true">→</span></a></div>
<div class="eg-f-ctas"><a class="eg-f-card" href="<?php echo $u( '/diagnostico-ia/' ); ?>" style="--c:var(--eg-ia)"><small>Para empezar</small><b>Diagnóstico IA · 2 h</b><span>Qué automatizar primero y cuánto te ahorra.</span><i aria-hidden="true">→</i></a><a class="eg-f-card" href="<?php echo $u( '/contacto/' ); ?>" style="--c:var(--eg-web)"><small>Webs y tiendas</small><b>Pide presupuesto web</b><span>Paquetes de precio cerrado, desde 1.290 €.</span><i aria-hidden="true">→</i></a></div></div>
<div class="eg-f-cols">
<div><h4>Servicios</h4><ul class="eg-f-svc">
<?php foreach ( eg_servicios() as $k => $s ) : ?><li><a href="<?php echo esc_url( eg_servicio_url( $k ) ); ?>"><?php echo eg_simbolo( $k ); // phpcs:ignore ?><b>eg</b>&nbsp;<?php echo esc_html( $s['nombre'] ); ?></a></li><?php endforeach; ?>
</ul></div>
<div><h4>Estudio</h4><ul><li><a href="<?php echo $u( '/proyectos/' ); ?>"><span class="eg-ul">Casos</span></a></li><li><a href="<?php echo $u( '/blog/' ); ?>"><span class="eg-ul">Blog</span></a></li><li><a href="<?php echo $u( '/novedades-ia/' ); ?>"><span class="eg-ul">Novedades IA</span></a></li><li><a href="<?php echo $u( '/estudio/' ); ?>"><span class="eg-ul">Sobre Enric</span></a></li><li><a href="<?php echo $u( '/area-de-clientes/' ); ?>"><span class="eg-ul">Área de clientes</span></a></li></ul></div>
<div><h4>Visítanos</h4><ul><li>C/ Costa i Fornaguera, 27<br>08370 Calella, Barcelona</li><li><a href="mailto:<?php echo esc_attr( $mail ); ?>"><span class="eg-ul"><?php echo esc_html( $mail ); ?></span></a></li></ul><div class="eg-soc"><?php foreach ( eg_redes() as $r ) : ?><a href="<?php echo esc_url( $r[1] ); ?>" aria-label="<?php echo esc_attr( $r[0] ); ?>" rel="noopener" target="_blank"><?php echo esc_html( $r[2] ); ?></a><?php endforeach; ?></div></div>
<div><h4>Idiomas</h4><ul><li><a href="<?php echo $u( '/' ); ?>" aria-current="true"><span class="eg-ul">Español</span></a></li><li><a href="<?php echo $u( '/ca/' ); ?>" hreflang="ca"><span class="eg-ul">Català</span></a></li><li><a href="<?php echo $u( '/en/' ); ?>" hreflang="en"><span class="eg-ul">English</span></a></li></ul></div></div>
<div class="eg-f-sign"><a class="eg-f-logo" href="#top" aria-label="enricgomez Studio, volver arriba"><?php echo eg_logo_svg(); // phpcs:ignore ?></a><p>Web · IA · Consultoría · Sistemas<br>Desde Calella para todo el mundo, desde 2006.</p><a class="eg-f-up" href="#top">Volver arriba ↑</a></div>
<div class="eg-f-legal"><span>© <?php echo esc_html( gmdate( 'Y' ) ); ?> EG Creative Studio S.L. · Hecho en Calella</span><nav aria-label="Legal"><a href="<?php echo $u( '/aviso-legal/' ); ?>">Aviso legal</a><a href="<?php echo $u( '/privacidad/' ); ?>">Privacidad</a><a href="<?php echo $u( '/cookies/' ); ?>">Cookies</a></nav></div>
</div></footer>
<?php wp_footer(); ?>
</body>
</html>
