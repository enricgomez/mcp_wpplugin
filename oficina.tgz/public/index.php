<?php
declare(strict_types=1);
require dirname(__DIR__) . '/private/oficina/lib/app.php';
require dirname(__DIR__) . '/private/oficina/lib/views.php';

security_headers();
start_session();

/* 1. Instalación / ajustes */
if (!is_configured() || isset($_GET['ajustes']) || isset($_GET['setup'])) {
    $editing = is_configured();
    if ($editing && !logged_in()) { render_login(); exit; }
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['setup'])) {
        check_csrf($_POST['csrf'] ?? null);
        $c = cfg();
        if (!$editing) {
            if (rl_blocked()) { render_setup('Demasiados intentos. Espera 15 minutos.'); exit; }
            $code = trim((string)($_POST['setup_code'] ?? ''));
            if (empty($c['setup_code_hash']) || !password_verify($code, $c['setup_code_hash'])) { rl_hit(false); render_setup('Código de instalación incorrecto.'); exit; }
        }
        $pw = (string)($_POST['password'] ?? '');
        $tok = trim((string)($_POST['notion_token'] ?? ''));
        $ical = trim((string)($_POST['ical_url'] ?? ''));
        if ($pw !== '' && mb_strlen($pw) < 10) { render_setup('La contraseña debe tener al menos 10 caracteres.', $editing); exit; }
        if ($ical !== '' && !preg_match('#^https://#', $ical)) { render_setup('La dirección del calendario debe empezar por https://', $editing); exit; }
        if ($tok !== '') {
            try { notion('POST', 'data_sources/' . DS_TAREAS . '/query', ['page_size' => 1], $tok); }
            catch (Throwable $e) { render_setup('El token no puede leer ✅ Tareas. ¿Has conectado la integración a la base? (' . $e->getMessage() . ')', $editing); exit; }
            $c['notion_token'] = $tok;
        }
        if ($pw !== '') { $c['password_hash'] = password_hash($pw, PASSWORD_DEFAULT); $c['auth_v'] = bin2hex(random_bytes(8)); }
        $c['ical_url'] = $ical;
        unset($c['setup_code_hash']);
        cfg_save($c);
        @unlink(OF_DIR . '/cache/ical.json');
        cache_clear();
        audit($editing ? 'ajustes guardados' : 'instalación completada');
        session_regenerate_id(true);
        $_SESSION['auth'] = 1; $_SESSION['auth_v'] = $c['auth_v'];
        header('Location: /'); exit;
    }
    render_setup('', $editing); exit;
}

/* 2. Login */
if (isset($_GET['salir'])) { $_SESSION = []; session_destroy(); header('Location: /'); exit; }
if (!logged_in()) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['login'])) {
        check_csrf($_POST['csrf'] ?? null);
        if (rl_blocked()) { render_login('Demasiados intentos. Espera 15 minutos.'); exit; }
        if (password_verify((string)($_POST['password'] ?? ''), cfg()['password_hash'])) {
            rl_hit(true); session_regenerate_id(true);
            $_SESSION['auth'] = 1; $_SESSION['auth_v'] = cfg()['auth_v'] ?? '';
            audit('login'); header('Location: /'); exit;
        }
        rl_hit(false); usleep(400000); render_login('Contraseña incorrecta.'); exit;
    }
    render_login(); exit;
}

/* 3. Panel */
$view = in_array($_GET['v'] ?? '', ['semana', 'clientes', 'facturar'], true) ? $_GET['v'] : 'inicio';
try { $data = load_data(isset($_GET['refresh'])); }
catch (Throwable $e) { render_error($e->getMessage()); exit; }
if (isset($_GET['refresh'])) { header('Location: /' . ($view !== 'inicio' ? '?v=' . $view : '')); exit; }
render_panel($data, $view);
