<?php
/**
 * Pie: la plantilla «Pie» del Theme Builder de Elementor Pro.
 */
defined( 'ABSPATH' ) || exit;
?>
</main>
<?php
if ( function_exists( 'elementor_theme_do_location' ) ) {
	elementor_theme_do_location( 'footer' );
}
wp_footer();
?>
</body>
</html>
