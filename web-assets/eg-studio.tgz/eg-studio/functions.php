<?php
/**
 * enricgomez Studio: tema hijo de Hello Elementor.
 */
defined( 'ABSPATH' ) || exit;

define( 'EG_THEME_VER', '1.1.0' );

require_once __DIR__ . '/inc/marca.php';

/* Hello Elementor: sin su CSS de reset/tema; el diseño lo llevan el kit de Elementor y assets/eg.css */
add_filter( 'hello_elementor_enqueue_style', '__return_false' );
add_filter( 'hello_elementor_enqueue_theme_style', '__return_false' );
add_filter( 'hello_elementor_header_footer', '__return_false' );

add_action( 'wp_enqueue_scripts', function () {
	$u = get_stylesheet_directory_uri();
	$p = get_stylesheet_directory();
	wp_enqueue_style( 'eg', $u . '/assets/eg.css', [], filemtime( $p . '/assets/eg.css' ) );
	wp_enqueue_script( 'eg', $u . '/assets/eg.js', [], filemtime( $p . '/assets/eg.js' ), [ 'strategy' => 'defer', 'in_footer' => true ] );
}, 20 );

/* Sora en local (variable, 300-700, latin): precarga */
add_action( 'wp_head', function () {
	$u = get_stylesheet_directory_uri() . '/fonts/';
	printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $u . 'sora-latin-var.woff2' ) );
}, 1 );

/* Elementor: no cargar Google Fonts (Sora va en local) */
add_filter( 'elementor/frontend/print_google_fonts', '__return_false' );

/* Limpieza de cabecera */
remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
add_filter( 'emoji_svg_url', '__return_false' );

/* Soportes */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', [ 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ] );
	add_image_size( 'eg-card', 800, 600, true );
	add_image_size( 'eg-wide', 1600, 900, true );
	register_nav_menus( [ 'principal' => 'Menú principal', 'pie' => 'Menú del pie', 'legal' => 'Menú legal' ] );
} );
