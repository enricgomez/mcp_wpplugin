/* enricgomez Studio: interacciones. Sin dependencias. Cada bloque comprueba que su sección exista. */
(() => {
	const $ = (s, c = document) => c.querySelector(s), $$ = (s, c = document) => [...c.querySelectorAll(s)];
	const RM = matchMedia('(prefers-reduced-motion: reduce)').matches;
	document.documentElement.classList.add('eg-js');

	/* Palabra que rota en el titular del hero */
	const t = $('.eg-hero-titulo > span');
	if (t) {
		const W = [['vende.', 'var(--eg-web)'], ['automatiza.', 'var(--eg-ia)'], ['orienta.', 'var(--eg-con2)'], ['funciona.', '#fff']];
		const r = document.createElement('span'); r.className = 'eg-rot'; r.setAttribute('aria-live', 'polite');
		W.forEach(([w, c], i) => { const s = document.createElement('span'); s.textContent = w; s.style.color = c; if (!i) s.className = 'on'; r.append(s); });
		t.replaceWith(r);
		if (!RM) { const s = $$('span', r); let i = 0; setInterval(() => { s[i].classList.remove('on'); i = (i + 1) % s.length; s[i].classList.add('on'); }, 2200); }
	}

	/* Botones: el relleno nace donde entra el cursor */
	$$('.eg-btn').forEach(b => { const set = e => { const r = b.getBoundingClientRect(); b.style.setProperty('--mx', (e.clientX - r.left) + 'px'); b.style.setProperty('--my', (e.clientY - r.top) + 'px'); }; b.addEventListener('pointerenter', set); b.addEventListener('pointerleave', set); });

	/* Cintas infinitas: se duplica el contenido para que el bucle no tenga salto */
	$$('.eg-ticker-fila, .eg-clientes-fila').forEach(f => { $$(':scope > *', f).forEach(n => { const c = n.cloneNode(true); c.setAttribute('aria-hidden', 'true'); f.append(c); }); });

	/* Escenario del hero: parallax, chat que cambia de idioma y marcador vivo */
	const st = $('.eg-escenario');
	if (st && !RM) {
		const cds = $$('.eg-tarjeta', st), D = [1.2, 1.6, .9, 1.4];
		if (matchMedia('(pointer: fine)').matches) {
			const hero = st.closest('.eg-hero');
			hero.addEventListener('pointermove', e => { const r = st.getBoundingClientRect(), c = v => Math.max(-.6, Math.min(.6, v)), x = c((e.clientX - r.left - r.width / 2) / r.width), y = c((e.clientY - r.top - r.height / 2) / r.height);
				cds.forEach((cd, i) => cd.style.transform = `translate(${(x * D[i] * 16).toFixed(1)}px,${(y * D[i] * 16).toFixed(1)}px)`); });
			hero.addEventListener('pointerleave', () => cds.forEach(cd => cd.style.transform = ''));
		}
		const Q = [['¿Tenéis parking para el 14 de agosto?', 'Sí, gratuito para clientes. ¿Te reservo plaza con la habitación?'], ['Do you have rooms with sea view?', 'Yes! Superior rooms face the sea. Shall I check your dates?'], ['Podeu fer pressupost per a 40 persones?', 'I tant. Et preparo el pressupost ara i te l’envio per correu.']];
		const me = $('.eg-msg-yo', st), bot = $('.eg-msg-bot', st); let qi = 1;
		if (me && bot) {
			bot.classList.add('eg-escribe'); setTimeout(() => bot.classList.remove('eg-escribe'), 2600);
			setTimeout(() => setInterval(() => { bot.classList.add('eg-escribe'); me.style.opacity = 0; setTimeout(() => { me.textContent = Q[qi][0]; bot.textContent = Q[qi][1]; me.style.opacity = 1; }, 300); setTimeout(() => bot.classList.remove('eg-escribe'), 2000); qi = (qi + 1) % Q.length; }, 6500), 2600);
		}
		const sc = $('.eg-marcador', st); let v = 187;
		if (sc) setInterval(() => { v += [0, 7, 9, 10, 8][Math.floor(Math.random() * 5)]; if (v > 299) v = 120; sc.textContent = v; }, 1800);
	}

	/* Proceso: se enciende al entrar en pantalla */
	const pc = $('.eg-proceso');
	if (pc) { if ('IntersectionObserver' in window && !RM) { const io = new IntersectionObserver(es => es.forEach(en => { if (en.isIntersecting) { pc.classList.add('eg-in'); io.disconnect(); } }), { threshold: .3 }); io.observe(pc); } else pc.classList.add('eg-in'); }

	/* Proyectos: carrusel con flechas, puntos con progreso y avance automático */
	const tr = $('.eg-casos-pista');
	if (tr) {
		const sec = tr.closest('.eg-seccion'), sl = $$('.eg-caso', tr), nav = $('.eg-casos-nav', sec), pts = $('.eg-puntos', sec);
		const VC = { 'eg web': 'eg-c-web', 'eg ia': 'eg-c-ia', 'eg consultoría': 'eg-c-con', 'eg sistemas': 'eg-c-sis' };
		sl.forEach(s => { const k = $('.eg-kicker', s), t = k ? k.textContent.trim().toLowerCase() : ''; Object.keys(VC).forEach(v => { if (t.endsWith(v)) s.classList.add(VC[v]); }); });
		if (sl.length > 1) {
			const mk = (cls, txt, lab) => { const b = document.createElement('button'); b.className = 'eg-flecha ' + cls; b.type = 'button'; b.textContent = txt; b.setAttribute('aria-label', lab); nav.append(b); return b; };
			const pv = mk('prev', '←', 'Proyecto anterior'), nx = mk('next', '→', 'Proyecto siguiente');
			const ds = sl.map((s, k) => { const b = document.createElement('button'); b.className = 'eg-punto'; b.type = 'button'; b.setAttribute('aria-label', 'Proyecto ' + (k + 1)); b.innerHTML = '<i></i>'; pts && pts.append(b); return b; });
			let i = 0, tm;
			const mark = n => { i = n; sl.forEach((s, k) => s.classList.toggle('on', k === n)); ds.forEach((d, k) => { d.classList.toggle('on', k === n); d.classList.toggle('visto', k < n); }); pv.disabled = n === 0; nx.disabled = n === sl.length - 1; };
			const arm = () => { clearTimeout(tm); if (!RM) tm = setTimeout(() => { if (!sec.classList.contains('eg-pausa')) go((i + 1) % sl.length); else arm(); }, 7000); };
			const go = n => { tr.scrollTo({ left: sl[n].offsetLeft - tr.offsetLeft, behavior: RM ? 'auto' : 'smooth' }); mark(n); arm(); };
			pv.onclick = () => go(Math.max(0, i - 1)); nx.onclick = () => go(Math.min(sl.length - 1, i + 1)); ds.forEach((d, k) => d.onclick = () => go(k));
			let stt; tr.addEventListener('scroll', () => { clearTimeout(stt); stt = setTimeout(() => { const n = Math.round(tr.scrollLeft / tr.clientWidth); if (n !== i) { mark(n); arm(); } }, 120); }, { passive: true });
			sec.addEventListener('pointerenter', e => { if (e.pointerType === 'mouse') sec.classList.add('eg-pausa'); }); sec.addEventListener('pointerleave', () => sec.classList.remove('eg-pausa'));
			const io = new IntersectionObserver(es => es.forEach(en => { if (en.isIntersecting) { mark(i); arm(); } else clearTimeout(tm); }), { threshold: .4 }); io.observe(sec); mark(0);
		} else sl.forEach(s => s.classList.add('on'));
	}

	/* Cabecera: isla flotante al bajar, barra de progreso, píldora del menú, mega menú táctil, menú móvil, logo del pie */
	const nav = $('.eg-nav'), pr = $('.eg-prog'), big = $('.eg-f-logo');
	let tick = false;
	const upd = () => { const y = scrollY, h = document.documentElement.scrollHeight - innerHeight; nav && nav.classList.toggle('eg-stuck', y > 40); pr && pr.style.setProperty('--p', h > 0 ? (y / h).toFixed(4) : 0); if (big) { const r = big.getBoundingClientRect(); big.classList.toggle('eg-lit', r.top < innerHeight - 40); } tick = false; };
	addEventListener('scroll', () => { if (!tick) { tick = true; requestAnimationFrame(upd); } }, { passive: true }); upd();
	const m = $('.eg-menu');
	if (m) { const pill = document.createElement('span'); pill.className = 'eg-pill'; pill.setAttribute('aria-hidden', 'true'); m.prepend(pill);
		$$('.eg-menu-a', m).forEach(a => a.addEventListener('mouseenter', () => { const r = a.getBoundingClientRect(), b = m.getBoundingClientRect(); pill.style.width = r.width + 'px'; pill.style.transform = 'translateX(' + (r.left - b.left) + 'px)'; pill.style.opacity = 1; })); m.addEventListener('mouseleave', () => pill.style.opacity = 0); }
	const hm = $('.eg-has-mm');
	if (hm) { const t = $('.eg-menu-a', hm); t && t.setAttribute('aria-haspopup', 'true');
		if (matchMedia('(hover: none)').matches && t) { t.addEventListener('click', e => { if (!hm.classList.contains('open')) { e.preventDefault(); hm.classList.add('open'); } }); document.addEventListener('click', e => { if (!hm.contains(e.target)) hm.classList.remove('open'); }); } }
	const bt = $('.eg-burger'), mob = $('.eg-mob');
	if (bt && mob) { const set = o => { document.body.classList.toggle('eg-menu-open', o); bt.setAttribute('aria-expanded', o); };
		bt.setAttribute('role', 'button'); bt.setAttribute('aria-label', 'Menú'); bt.setAttribute('aria-controls', 'eg-mob'); bt.setAttribute('aria-expanded', 'false'); mob.setAttribute('aria-label', 'Menú móvil');
		bt.addEventListener('click', e => { e.preventDefault(); set(!document.body.classList.contains('eg-menu-open')); });
		$$('a', mob).forEach((a, i) => { a.style.transitionDelay = (i * 40) + 'ms'; a.addEventListener('click', () => set(false)); });
		addEventListener('keydown', e => { if (e.key === 'Escape' && document.body.classList.contains('eg-menu-open')) { set(false); bt.focus(); } }); }
	/* etiquetas accesibles del logo y las redes */
	$$('.eg-logo, .eg-f-logo').forEach(l => l.setAttribute('aria-label', l.classList.contains('eg-logo') ? 'enricgomez Studio, inicio' : 'enricgomez Studio, volver arriba'));
	$$('.eg-soc-a').forEach(l => l.setAttribute('aria-label', { fb: 'Facebook', ig: 'Instagram', in: 'LinkedIn', x: 'X' }[l.textContent.trim()] || l.textContent));
})();
