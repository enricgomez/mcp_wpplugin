<?php
declare(strict_types=1);
require dirname(__DIR__) . '/private/oficina/lib/app.php';

security_headers();
header('Content-Type: application/json; charset=utf-8');
start_session();

function out(array $d, int $code = 200): never { http_response_code($code); echo json_encode($d, JSON_UNESCAPED_UNICODE); exit; }

if (!is_configured() || !logged_in()) out(['ok' => false, 'error' => 'Sesión caducada. Vuelve a entrar.'], 401);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') out(['ok' => false, 'error' => 'Método no permitido'], 405);
$in = json_decode((string)file_get_contents('php://input'), true) ?: [];
if (!hash_equals(csrf(), (string)($in['csrf'] ?? ''))) out(['ok' => false, 'error' => 'Recarga la página.'], 403);

$act = (string)($in['act'] ?? '');
$id  = (string)($in['id'] ?? '');
$needsId = !in_array($act, ['create', 'refresh'], true);
if ($needsId && !valid_id($id)) out(['ok' => false, 'error' => 'Tarea no válida'], 400);

$ESTADOS = ['', 'Bandeja', 'Hoy', 'Esta semana', 'Esperando', 'Hecha'];
$PRIOS = ['', 'Alta', 'Media', 'Baja'];
$ESPERA = ['', 'Enric', 'Cliente', 'Claude'];

try {
    switch ($act) {
        case 'done':
            update_task($id, ['Estado' => sel('Hecha'), 'Espera a' => sel(null)]);
            audit("hecha $id"); $msg = 'Hecha ✓'; break;

        case 'postpone':
            $d = (string)($in['fecha'] ?? '');
            if (!valid_date($d)) { $d = add_days(today(), max(1, min(60, (int)($in['days'] ?? 1)))); }
            $props = ['Fecha límite' => date_prop($d)];
            if (($in['estado'] ?? '') === 'Hoy' && $d > today()) $props['Estado'] = sel('Esta semana');
            update_task($id, $props);
            audit("aplazada $id $d"); $msg = 'Aplazada al ' . date('j/n', strtotime($d)); break;

        case 'save':
            $f = $in['fields'] ?? [];
            $props = [];
            if (array_key_exists('estado', $f) && in_array($f['estado'], $ESTADOS, true)) $props['Estado'] = sel($f['estado']);
            if (array_key_exists('prioridad', $f) && in_array($f['prioridad'], $PRIOS, true)) $props['Prioridad'] = sel($f['prioridad']);
            if (array_key_exists('espera', $f) && in_array($f['espera'], $ESPERA, true)) $props['Espera a'] = sel($f['espera']);
            if (array_key_exists('fecha', $f)) $props['Fecha límite'] = date_prop(valid_date((string)$f['fecha']) ? $f['fecha'] : null);
            if (array_key_exists('facturar', $f)) $props['Para facturar'] = ['checkbox' => (bool)$f['facturar']];
            if (array_key_exists('importe', $f)) $props['Importe'] = ['number' => ($f['importe'] === '' || $f['importe'] === null) ? null : (float)$f['importe']];
            if (!$props) out(['ok' => false, 'error' => 'Nada que guardar'], 400);
            update_task($id, $props);
            audit("guardada $id " . implode(',', array_keys($props))); $msg = 'Guardado'; break;

        case 'note':
            $t = trim((string)($in['texto'] ?? ''));
            if ($t === '') out(['ok' => false, 'error' => 'La nota está vacía'], 400);
            add_note($id, $t); audit("nota $id"); $msg = 'Nota guardada'; break;

        case 'delegate':
            $t = trim((string)($in['texto'] ?? ''));
            if ($t === '') out(['ok' => false, 'error' => 'Escribe o dicta la orden'], 400);
            update_task($id, ['Encargo a Claude' => ['rich_text' => rt($t)], 'Espera a' => sel('Claude')]);
            add_note($id, '🤖 Encargo a Claude: ' . $t);
            audit("encargo $id"); $msg = 'Encargado a Claude'; break;

        case 'approve-draft':
            $t = '✅ Borrador de respuesta aprobado por Enric desde el panel: déjalo como borrador en Gmail (respuesta en el hilo indicado) y avisa.';
            update_task($id, ['Encargo a Claude' => ['rich_text' => rt($t)], 'Espera a' => sel('Claude')]);
            add_note($id, $t); audit("borrador aprobado $id"); $msg = 'Borrador aprobado'; break;

        case 'facturado':
            update_task($id, ['Para facturar' => ['checkbox' => false]]);
            add_note($id, '💶 Marcada como facturada'); audit("facturada $id"); $msg = 'Marcada como facturada'; break;

        case 'create':
            $titulo = trim((string)($in['titulo'] ?? ''));
            if ($titulo === '') out(['ok' => false, 'error' => 'Falta qué hay que hacer'], 400);
            $estado = in_array($in['estado'] ?? '', $ESTADOS, true) && ($in['estado'] ?? '') !== '' ? $in['estado'] : 'Bandeja';
            $props = [
                'Tarea' => ['title' => rt(mb_strimwidth($titulo, 0, 180, '…'))],
                'Estado' => sel($estado),
                'Negocio' => sel('enricgomez Studio'),
            ];
            if (in_array($in['prioridad'] ?? '', $PRIOS, true) && ($in['prioridad'] ?? '') !== '') $props['Prioridad'] = sel($in['prioridad']);
            if (valid_date((string)($in['fecha'] ?? ''))) $props['Fecha límite'] = date_prop($in['fecha']);
            if (valid_id((string)($in['cliente'] ?? ''))) $props['Cliente'] = ['relation' => [['id' => $in['cliente']]]];
            if (!empty($in['delegar'])) { $props['Encargo a Claude'] = ['rich_text' => rt($titulo)]; $props['Espera a'] = sel('Claude'); }
            $pg = notion('POST', 'pages', ['parent' => ['type' => 'data_source_id', 'data_source_id' => DS_TAREAS], 'properties' => $props,
                'children' => mb_strlen($titulo) > 180 ? [['object' => 'block', 'type' => 'paragraph', 'paragraph' => ['rich_text' => rt($titulo)]]] : []]);
            audit('creada ' . ($pg['id'] ?? '?') . (!empty($in['delegar']) ? ' (encargo)' : ''));
            $msg = !empty($in['delegar']) ? 'Encargo creado' : 'Tarea creada'; break;

        case 'refresh':
            $msg = 'Actualizado'; break;

        default:
            out(['ok' => false, 'error' => 'Acción desconocida'], 400);
    }
    cache_clear();
    out(['ok' => true, 'msg' => $msg]);
} catch (Throwable $e) {
    out(['ok' => false, 'error' => $e->getMessage()], 502);
}
