<?php
/**
 * Cabecera: la plantilla «Cabecera» del Theme Builder de Elementor Pro. Aquí solo queda lo que no es contenido.
 */
defined( 'ABSPATH' ) || exit;
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<span id="top"></span><a class="eg-skip" href="#contenido">Saltar al contenido</a>
<div class="eg-prog" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
<?php
if ( function_exists( 'elementor_theme_do_location' ) ) {
	elementor_theme_do_location( 'header' );
}
?>
<main id="contenido">
