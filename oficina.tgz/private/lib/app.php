<?php
/**
 * Oficina EG · panel de gestión de enricgomez STUDIO
 * Núcleo: configuración, sesión, seguridad, Notion, caché y modelo de datos.
 * Vive FUERA del docroot: /var/www/vhosts/enricgomez.com/private/oficina/lib/
 */
declare(strict_types=1);

define('OF_DIR', dirname(__DIR__));            // .../private/oficina
const OF_VERSION   = '1.0.0';
const DS_TAREAS    = '6c3b81e0-6a16-4b23-9f94-bb3ff5423b1d';
const DS_CLIENTES  = '38a8f161-7f30-4228-9c1c-92836919c60e';
const DS_PROYECTOS = '840ecc2e-95d8-43c2-9242-73145970c76c';
const NOTION_VERSION = '2025-09-03';
const CACHE_TTL    = 90;      // segundos
const SESSION_DAYS = 30;

date_default_timezone_set('Asia/Tokyo');
mb_internal_encoding('UTF-8');

/* ------------------------------------------------------------------ config */

function cfg(): array {
    static $c = null;
    if ($c === null) {
        $f = OF_DIR . '/config.json';
        $c = is_file($f) ? (json_decode((string)file_get_contents($f), true) ?: []) : [];
    }
    return $c;
}

function cfg_save(array $c): void {
    $f = OF_DIR . '/config.json';
    $tmp = $f . '.' . bin2hex(random_bytes(4));
    file_put_contents($tmp, json_encode($c, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    @chmod($tmp, 0600);
    rename($tmp, $f);
}

function is_configured(): bool {
    $c = cfg();
    return !empty($c['password_hash']) && !empty($c['notion_token']);
}

/* ---------------------------------------------------------------- security */

function security_headers(): void {
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
    header('Cache-Control: no-store');
}

function start_session(): void {
    $dir = OF_DIR . '/sessions';
    if (!is_dir($dir)) { @mkdir($dir, 0700, true); }
    session_save_path($dir);
    ini_set('session.gc_maxlifetime', (string)(SESSION_DAYS * 86400));
    ini_set('session.use_strict_mode', '1');
    session_name('oficina_eg');
    session_set_cookie_params([
        'lifetime' => SESSION_DAYS * 86400, 'path' => '/', 'secure' => true,
        'httponly' => true, 'samesite' => 'Lax',
    ]);
    session_start();
    if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
}

function logged_in(): bool { return !empty($_SESSION['auth']) && ($_SESSION['auth_v'] ?? '') === (cfg()['auth_v'] ?? ''); }

function csrf(): string { return $_SESSION['csrf'] ?? ''; }

function check_csrf(?string $t): void {
    if (!$t || !hash_equals(csrf(), $t)) { http_response_code(403); exit('CSRF'); }
}

function client_ip(): string { return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'; }

/** Límite de intentos: 5 fallos en 15 min por IP. */
function rl_file(): string { return OF_DIR . '/ratelimit.json'; }
function rl_blocked(): bool {
    $d = is_file(rl_file()) ? (json_decode((string)file_get_contents(rl_file()), true) ?: []) : [];
    $e = $d[client_ip()] ?? null;
    return $e && $e['n'] >= 5 && time() - $e['t'] < 900;
}
function rl_hit(bool $ok): void {
    $d = is_file(rl_file()) ? (json_decode((string)file_get_contents(rl_file()), true) ?: []) : [];
    foreach ($d as $ip => $e) { if (time() - $e['t'] > 900) unset($d[$ip]); }
    if ($ok) { unset($d[client_ip()]); }
    else { $e = $d[client_ip()] ?? ['n' => 0, 't' => time()]; $e['n']++; $e['t'] = time(); $d[client_ip()] = $e; }
    file_put_contents(rl_file(), json_encode($d), LOCK_EX);
}

function h(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function audit(string $what): void {
    $line = date('c') . ' ' . client_ip() . ' ' . str_replace(["\n", "\r"], ' ', $what) . "\n";
    file_put_contents(OF_DIR . '/acciones.log', $line, FILE_APPEND | LOCK_EX);
}

/* ------------------------------------------------------------------ notion */

function notion(string $method, string $path, ?array $body = null, ?string $token = null): array {
    $token = $token ?? (cfg()['notion_token'] ?? '');
    $ch = curl_init('https://api.notion.com/v1/' . ltrim($path, '/'));
    $opts = [
        CURLOPT_CUSTOMREQUEST => $method,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $token,
            'Notion-Version: ' . NOTION_VERSION,
            'Content-Type: application/json',
        ],
    ];
    if ($body !== null) { $opts[CURLOPT_POSTFIELDS] = json_encode($body, JSON_UNESCAPED_UNICODE); }
    curl_setopt_array($ch, $opts);
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err = curl_error($ch);
    curl_close($ch);
    if ($raw === false) { throw new RuntimeException('Sin conexión con Notion: ' . $err); }
    $j = json_decode((string)$raw, true) ?: [];
    if ($code >= 300) { throw new RuntimeException('Notion ' . $code . ': ' . ($j['message'] ?? 'error')); }
    return $j;
}

function query_all(string $ds, array $body = [], int $maxPages = 10): array {
    $out = []; $cursor = null; $i = 0;
    do {
        $b = $body + ['page_size' => 100];
        if ($cursor) { $b['start_cursor'] = $cursor; }
        $r = notion('POST', 'data_sources/' . $ds . '/query', $b);
        $out = array_merge($out, $r['results'] ?? []);
        $cursor = ($r['has_more'] ?? false) ? ($r['next_cursor'] ?? null) : null;
    } while ($cursor && ++$i < $maxPages);
    return $out;
}

/* ------------------------------------------------------------------- cache */

function cache_get(string $key, int $ttl, callable $fn) {
    $dir = OF_DIR . '/cache';
    if (!is_dir($dir)) { @mkdir($dir, 0700, true); }
    $f = $dir . '/' . preg_replace('/[^a-z0-9_-]/i', '', $key) . '.json';
    if (is_file($f) && time() - filemtime($f) < $ttl) {
        $d = json_decode((string)file_get_contents($f), true);
        if ($d !== null) { return $d; }
    }
    $d = $fn();
    file_put_contents($f, json_encode($d, JSON_UNESCAPED_UNICODE), LOCK_EX);
    return $d;
}

function cache_clear(): void {
    foreach (glob(OF_DIR . '/cache/*.json') ?: [] as $f) { if (basename($f) !== 'ical.json') @unlink($f); }
}

/* ------------------------------------------------------------- data model */

function p_text(?array $p): string {
    if (!$p) return '';
    $arr = $p['title'] ?? $p['rich_text'] ?? [];
    return trim(implode('', array_map(fn($t) => $t['plain_text'] ?? '', $arr)));
}
function p_select(?array $p): string { return $p['select']['name'] ?? ''; }
function p_rel(?array $p): array { return array_map(fn($r) => $r['id'], $p['relation'] ?? []); }

function map_task(array $pg): array {
    $p = $pg['properties'] ?? [];
    return [
        'id'        => $pg['id'],
        'url'       => $pg['url'] ?? '',
        'titulo'    => p_text($p['Tarea'] ?? null) ?: '(sin título)',
        'estado'    => p_select($p['Estado'] ?? null),
        'prioridad' => p_select($p['Prioridad'] ?? null),
        'negocio'   => p_select($p['Negocio'] ?? null),
        'duracion'  => p_select($p['Duración estimada'] ?? null),
        'espera'    => p_select($p['Espera a'] ?? null),
        'fecha'     => substr((string)($p['Fecha límite']['date']['start'] ?? ''), 0, 10),
        'facturar'  => (bool)($p['Para facturar']['checkbox'] ?? false),
        'importe'   => $p['Importe']['number'] ?? null,
        'encargo'   => p_text($p['Encargo a Claude'] ?? null),
        'borrador'  => p_text($p['Borrador respuesta'] ?? null),
        'gmail'     => (string)($p['Hilo Gmail']['url'] ?? ''),
        'clientes'  => p_rel($p['Cliente'] ?? null),
        'proyectos' => p_rel($p['Proyecto'] ?? null),
        'editada'   => $pg['last_edited_time'] ?? '',
    ];
}

function load_data(bool $force = false): array {
    if ($force) cache_clear();
    return cache_get('datos', CACHE_TTL, function () {
        $tareas = array_map('map_task', query_all(DS_TAREAS, [
            'filter' => ['or' => [
                ['property' => 'Estado', 'select' => ['does_not_equal' => 'Hecha']],
                ['property' => 'Para facturar', 'checkbox' => ['equals' => true]],
            ]],
            'sorts' => [['property' => 'Fecha límite', 'direction' => 'ascending']],
        ]));
        $clientes = [];
        foreach (query_all(DS_CLIENTES, [], 3) as $pg) {
            $p = $pg['properties'] ?? [];
            $name = '';
            foreach ($p as $prop) { if (($prop['type'] ?? '') === 'title') { $name = p_text($prop); break; } }
            $clientes[$pg['id']] = [
                'id' => $pg['id'], 'nombre' => $name ?: '(sin nombre)',
                'estado' => p_select($p['Estado'] ?? null), 'url' => $pg['url'] ?? '',
                'web' => (string)($p['Web']['url'] ?? ''),
            ];
        }
        $proyectos = [];
        foreach (query_all(DS_PROYECTOS, ['filter' => ['property' => 'Estado', 'select' => ['equals' => 'Activo']]], 3) as $pg) {
            $p = $pg['properties'] ?? [];
            $proyectos[$pg['id']] = [
                'id' => $pg['id'], 'nombre' => p_text($p['Nombre'] ?? null),
                'proxima' => p_text($p['Próxima acción'] ?? null),
                'clientes' => p_rel($p['Cliente'] ?? null),
                'fecha' => substr((string)($p['Fecha objetivo']['date']['start'] ?? ''), 0, 10),
            ];
        }
        return ['tareas' => $tareas, 'clientes' => $clientes, 'proyectos' => $proyectos, 'leido' => time()];
    });
}

function today(): string { return date('Y-m-d'); }
function add_days(string $d, int $n): string { return date('Y-m-d', strtotime($d . ' ' . ($n >= 0 ? '+' : '') . $n . ' days')); }

/** Agrupa las tareas en los bloques del panel. */
function build_blocks(array $data): array {
    $t = today(); $week = add_days($t, 7);
    $b = ['espera' => [], 'atrasadas' => [], 'hoy' => [], 'semana' => [], 'esperando' => [],
          'claude' => [], 'bandeja' => [], 'facturar' => [], 'clientes' => []];
    $prioOrder = ['Alta' => 0, 'Media' => 1, 'Baja' => 2, '' => 3];
    foreach ($data['tareas'] as $x) {
        if ($x['facturar']) $b['facturar'][] = $x;
        if ($x['estado'] === 'Hecha') continue;
        foreach ($x['clientes'] ?: ['_'] as $cid) { $b['clientes'][$cid][] = $x; }
        if ($x['espera'] === 'Enric') { $b['espera'][] = $x; continue; }
        if ($x['espera'] === 'Claude') { $b['claude'][] = $x; continue; }
        if ($x['estado'] === 'Esperando' || $x['espera'] === 'Cliente') { $b['esperando'][] = $x; continue; }
        if ($x['fecha'] && $x['fecha'] < $t) { $b['atrasadas'][] = $x; continue; }
        if ($x['estado'] === 'Hoy' || $x['fecha'] === $t) { $b['hoy'][] = $x; continue; }
        if ($x['estado'] === 'Esta semana' || ($x['fecha'] && $x['fecha'] <= $week)) { $b['semana'][] = $x; continue; }
        $b['bandeja'][] = $x;
    }
    $sort = function (&$arr) use ($prioOrder) {
        usort($arr, fn($a, $c) => [$prioOrder[$a['prioridad']] ?? 3, $a['fecha'] ?: '9999'] <=> [$prioOrder[$c['prioridad']] ?? 3, $c['fecha'] ?: '9999']);
    };
    foreach (['espera', 'hoy', 'semana', 'esperando', 'claude', 'bandeja', 'facturar'] as $k) $sort($b[$k]);
    usort($b['atrasadas'], fn($a, $c) => strcmp($a['fecha'], $c['fecha']));
    return $b;
}

/* ----------------------------------------------------------------- writes */

function rt(string $s): array {
    $out = [];
    foreach (mb_str_split($s, 1900) ?: [''] as $chunk) { $out[] = ['type' => 'text', 'text' => ['content' => $chunk]]; }
    return $s === '' ? [] : $out;
}

function sel(?string $v): array { return ['select' => ($v === null || $v === '') ? null : ['name' => $v]]; }

function date_prop(?string $d): array { return ['date' => $d ? ['start' => $d] : null]; }

function update_task(string $id, array $props): void {
    notion('PATCH', 'pages/' . $id, ['properties' => $props]);
}

function add_note(string $id, string $text): void {
    $stamp = date('d/m H:i');
    notion('PATCH', 'blocks/' . $id . '/children', ['children' => [[
        'object' => 'block', 'type' => 'paragraph',
        'paragraph' => ['rich_text' => rt('📝 ' . $stamp . ' (panel): ' . $text)],
    ]]]);
}

function valid_id(string $id): bool { return (bool)preg_match('/^[0-9a-f-]{32,36}$/i', $id); }
function valid_date(string $d): bool { return (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $d); }

/* ----------------------------------------------------------------- ical */

function ical_events(int $days = 7): array {
    $url = cfg()['ical_url'] ?? '';
    if (!$url) return [];
    try {
        $raw = cache_get('ical', 600, function () use ($url) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_FOLLOWLOCATION => true]);
            $r = curl_exec($ch); curl_close($ch);
            return ['ics' => is_string($r) ? $r : ''];
        });
    } catch (Throwable $e) { return []; }
    return parse_ics($raw['ics'] ?? '', $days);
}

function ics_dt(string $key, string $val): array {
    // devuelve [timestamp, allDay]
    $allDay = str_contains($key, 'VALUE=DATE') && !str_contains($key, 'DATE-TIME');
    $tz = null;
    if (preg_match('/TZID=([^;:]+)/', $key, $m)) { try { $tz = new DateTimeZone($m[1]); } catch (Throwable $e) { $tz = null; } }
    if ($allDay || preg_match('/^\d{8}$/', $val)) {
        $d = DateTime::createFromFormat('Ymd H:i:s', $val . ' 00:00:00', new DateTimeZone('Asia/Tokyo'));
        return [$d ? $d->getTimestamp() : 0, true];
    }
    if (str_ends_with($val, 'Z')) { $d = DateTime::createFromFormat('Ymd\THis\Z', $val, new DateTimeZone('UTC')); }
    else { $d = DateTime::createFromFormat('Ymd\THis', $val, $tz ?? new DateTimeZone('Europe/Madrid')); }
    return [$d ? $d->getTimestamp() : 0, false];
}

function parse_ics(string $ics, int $days): array {
    if ($ics === '') return [];
    $ics = preg_replace("/\r?\n[ \t]/", '', $ics);
    $from = strtotime('today'); $to = $from + $days * 86400;
    $events = [];
    preg_match_all('/BEGIN:VEVENT(.*?)END:VEVENT/s', $ics, $m);
    foreach ($m[1] as $block) {
        $f = []; $ex = [];
        foreach (preg_split("/\r?\n/", trim($block)) as $line) {
            if (!str_contains($line, ':')) continue;
            [$k, $v] = explode(':', $line, 2);
            $name = explode(';', $k)[0];
            if ($name === 'EXDATE') { foreach (explode(',', $v) as $x) $ex[] = ics_dt($k, $x)[0]; continue; }
            $f[$name] = [$k, $v];
        }
        if (!isset($f['DTSTART'])) continue;
        if (isset($f['STATUS']) && $f['STATUS'][1] === 'CANCELLED') continue;
        [$start, $allDay] = ics_dt($f['DTSTART'][0], $f['DTSTART'][1]);
        $title = stripcslashes(str_replace(['\\,', '\\;', '\\n'], [',', ';', ' '], $f['SUMMARY'][1] ?? '(sin título)'));
        $occ = [$start];
        if (isset($f['RRULE'])) {
            parse_str(str_replace(';', '&', $f['RRULE'][1]), $r);
            $freq = $r['FREQ'] ?? ''; $int = max(1, (int)($r['INTERVAL'] ?? 1));
            $until = isset($r['UNTIL']) ? ics_dt('', $r['UNTIL'])[0] : PHP_INT_MAX;
            $count = isset($r['COUNT']) ? (int)$r['COUNT'] : PHP_INT_MAX;
            $byday = isset($r['BYDAY']) ? explode(',', $r['BYDAY']) : [];
            $map = ['MO' => 1, 'TU' => 2, 'WE' => 3, 'TH' => 4, 'FR' => 5, 'SA' => 6, 'SU' => 7];
            $occ = []; $n = 0; $cur = $start; $guard = 0;
            while ($cur <= $to && $cur <= $until && $n < $count && $guard++ < 4000) {
                if ($freq === 'WEEKLY' && $byday) {
                    $weekStart = strtotime('monday this week', $cur) + ($cur - strtotime('today', $cur));
                    foreach ($byday as $bd) {
                        $bd = preg_replace('/[^A-Z]/', '', $bd);
                        if (!isset($map[$bd])) continue;
                        $o = $weekStart + ($map[$bd] - 1) * 86400;
                        if ($o >= $start && $o <= $until && $n < $count) { $occ[] = $o; $n++; }
                    }
                    $cur = strtotime('+' . $int . ' week', $cur);
                } else {
                    $occ[] = $cur; $n++;
                    $step = ['DAILY' => 'day', 'WEEKLY' => 'week', 'MONTHLY' => 'month', 'YEARLY' => 'year'][$freq] ?? null;
                    if (!$step) break;
                    $cur = strtotime('+' . $int . ' ' . $step, $cur);
                }
            }
        }
        foreach ($occ as $o) {
            if (in_array($o, $ex, true)) continue;
            if ($o >= $from && $o < $to) $events[] = ['ts' => $o, 'allday' => $allDay, 'titulo' => $title];
        }
    }
    usort($events, fn($a, $b) => $a['ts'] <=> $b['ts']);
    return array_slice($events, 0, 40);
}
