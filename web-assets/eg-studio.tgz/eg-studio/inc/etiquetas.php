<?php
/**
 * Etiquetas dinámicas propias para los elementos atómicos de Elementor 4.
 * Las de Elementor/JetEngine con controles avanzados no se convierten a V4; estas sí
 * (un solo control «campo» con valor por defecto).
 */
defined( 'ABSPATH' ) || exit;

function eg_dato( string $campo, ?int $id = null ): string {
	$id = $id ?: get_the_ID();
	$svc = [ 'web' => 'eg web', 'ia' => 'eg ia', 'consultoria' => 'eg consultoría', 'sistemas' => 'eg sistemas' ];
	switch ( $campo ) {
		case 'titulo': return get_the_title( $id );
		case 'extracto': return get_the_excerpt( $id );
		case 'servicio': return $svc[ get_post_meta( $id, 'servicio', true ) ] ?? 'eg web';
		case 'servicio_slug': return (string) get_post_meta( $id, 'servicio', true ) ?: 'web';
		case 'kicker': return '<span></span>Proyecto · ' . eg_dato( 'servicio', $id );
		case 'tipologia':
			$t = get_the_terms( $id, 'tipologia' ); return $t && ! is_wp_error( $t ) ? $t[0]->name : '';
		case 'tipologias':
			$t = get_the_terms( $id, 'tipologia' ); return $t && ! is_wp_error( $t ) ? implode( ' · ', wp_list_pluck( $t, 'name' ) ) : '';
		case 'web_host':
			$u = get_post_meta( $id, 'web', true ); return $u ? preg_replace( '#^www\.#', '', (string) wp_parse_url( $u, PHP_URL_HOST ) ) : '';
		case 'web_enlace':
			$u = get_post_meta( $id, 'web', true ); return $u ? '<a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">' . esc_html( eg_dato( 'web_host', $id ) ) . ' ↗</a>' : '';
		case 'anterior':
		case 'siguiente':
			$GLOBALS['post'] = get_post( $id ); setup_postdata( $GLOBALS['post'] );
			$a = get_adjacent_post( false, '', 'anterior' === $campo ); wp_reset_postdata();
			if ( ! $a ) return '';
			return '<a href="' . esc_url( get_permalink( $a ) ) . '"><span>' . ( 'anterior' === $campo ? '← Proyecto anterior' : 'Proyecto siguiente →' ) . '</span><b>' . esc_html( get_the_title( $a ) ) . '</b></a>';
		case 'archivo_titulo':
			return is_tax( 'tipologia' ) ? single_term_title( '', false ) : 'Proyectos';
		case 'archivo_texto':
			if ( is_tax( 'tipologia' ) ) { $d = term_description(); return $d ? wp_strip_all_tags( $d ) : 'Proyectos de ' . mb_strtolower( single_term_title( '', false ) ) . ': qué pedía cada cliente, qué hicimos y cómo quedó.'; }
			return 'Webs, inteligencia artificial, consultoría y sistemas para empresas, hoteles y entidades. Qué pedía cada cliente, qué hicimos y cómo quedó.';
		case 'archivo_filtro':
			$cur = is_tax( 'tipologia' ) ? get_queried_object_id() : 0;
			$o = $cur ? '<a href="' . esc_url( get_post_type_archive_link( 'proyecto' ) ) . '">Todos</a>' : '<b>Todos</b>';
			foreach ( get_terms( [ 'taxonomy' => 'tipologia', 'hide_empty' => true ] ) as $t ) $o .= $t->term_id === $cur ? '<b>' . esc_html( $t->name ) . '</b>' : '<a href="' . esc_url( get_term_link( $t ) ) . '">' . esc_html( $t->name ) . '</a>';
			return $o;
		case 'fecha': return get_the_date( '', $id );
		case 'lectura':
			$w = str_word_count( wp_strip_all_tags( get_post_field( 'post_content', $id ) ) ); return max( 1, (int) round( $w / 220 ) ) . ' min de lectura';
	}
	if ( 0 === strpos( $campo, 'f_' ) ) { // fila de la ficha: vacía si el mismo dato ya sale en las cifras
		$k = substr( $campo, 2 ); $lab = [ 'sector' => 'sector', 'anio' => 'año', 'servicio' => 'servicio', 'cliente' => 'cliente' ][ $k ] ?? $k;
		foreach ( (array) get_post_meta( $id, 'datos', true ) as $d ) if ( mb_strtolower( trim( $d['etiqueta'] ?? '' ) ) === $lab ) return '';
		return eg_dato( $k, $id );
	}
	if ( preg_match( '/^datos\.(\d)\.(etiqueta|valor)$/', $campo, $m ) ) {
		$d = array_values( (array) get_post_meta( $id, 'datos', true ) ); return (string) ( $d[ (int) $m[1] ][ $m[2] ] ?? '' );
	}
	$v = get_post_meta( $id, $campo, true );
	return is_scalar( $v ) ? (string) $v : '';
}

function eg_imagen_id( string $campo, ?int $id = null ): int {
	$id = $id ?: get_the_ID();
	if ( 'destacada' === $campo ) return (int) get_post_thumbnail_id( $id );
	if ( preg_match( '/^galeria\.(\d+)$/', $campo, $m ) ) {
		$g = array_values( array_filter( array_map( 'intval', explode( ',', (string) get_post_meta( $id, 'galeria', true ) ) ) ) );
		return $g[ (int) $m[1] ] ?? 0;
	}
	return (int) get_post_meta( $id, $campo, true );
}

add_action( 'elementor/dynamic_tags/register', function ( $tags ) {
	$tags->register_group( 'eg', [ 'title' => 'enricgomez' ] );

	$tags->register( new class() extends \Elementor\Core\DynamicTags\Tag {
		public function get_name() { return 'eg-dato'; }
		public function get_title() { return 'EG · Dato'; }
		public function get_group() { return 'eg'; }
		public function get_categories() { return [ \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY ]; }
		protected function register_advanced_section() {}
		protected function register_controls() {
			$this->add_control( 'campo', [ 'label' => 'Campo', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'titulo' ] );
		}
		public function render() { echo wp_kses_post( eg_dato( (string) $this->get_settings( 'campo' ) ) ); }
	} );

	$tags->register( new class() extends \Elementor\Core\DynamicTags\Data_Tag {
		public function get_name() { return 'eg-imagen'; }
		public function get_title() { return 'EG · Imagen'; }
		public function get_group() { return 'eg'; }
		public function get_categories() { return [ \Elementor\Modules\DynamicTags\Module::IMAGE_CATEGORY ]; }
		protected function register_controls() {
			$this->add_control( 'campo', [ 'label' => 'Campo', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'destacada' ] );
		}
		public function get_value( array $options = [] ) {
			$i = eg_imagen_id( (string) $this->get_settings( 'campo' ) );
			return $i ? [ 'id' => $i, 'url' => wp_get_attachment_image_url( $i, 'full' ) ] : [ 'id' => null, 'url' => '' ];
		}
	} );

	$tags->register( new class() extends \Elementor\Core\DynamicTags\Data_Tag {
		public function get_name() { return 'eg-url'; }
		public function get_title() { return 'EG · Enlace'; }
		public function get_group() { return 'eg'; }
		public function get_categories() { return [ \Elementor\Modules\DynamicTags\Module::URL_CATEGORY ]; }
		protected function register_controls() {
			$this->add_control( 'campo', [ 'label' => 'Campo', 'type' => \Elementor\Controls_Manager::TEXT, 'default' => 'web' ] );
		}
		public function get_value( array $options = [] ) {
			$c = (string) $this->get_settings( 'campo' );
			if ( 'archivo' === $c ) return get_post_type_archive_link( get_post_type() ?: 'proyecto' );
			return esc_url( eg_dato( $c ) );
		}
	} );
} );
