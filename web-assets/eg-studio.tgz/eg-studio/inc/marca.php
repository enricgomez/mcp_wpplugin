<?php
/**
 * Marca: logo, símbolo de 4 piezas y datos de los servicios (se usan en cabecera, menú móvil y pie).
 */
defined( 'ABSPATH' ) || exit;

function eg_logo_svg() {
	static $svg = null;
	if ( null === $svg ) {
		$svg = (string) file_get_contents( get_stylesheet_directory() . '/logo.svg' );
	}
	return $svg;
}

/** Símbolo mini con la pieza del servicio encendida. $fondo: oscuro|claro */
function eg_simbolo( $k, $fondo = 'oscuro', $clase = 'eg-mini' ) {
	$d   = [
		'M -4 -99.920 L -4 -63.826 A 46 46 0 0 0 -46 -18 L -4 -18 L -4 18 L -98.367 18 A 100 100 0 0 1 -4 -99.920 Z',
		'M -96.561 26 L -46 26 A 46 46 0 0 0 -4 71.826 L -4 99.920 A 100 100 0 0 1 -96.561 26 Z',
		'M 4 -99.920 A 100 100 0 0 1 98.367 -18 L 46 -18 A 46 46 0 0 0 4 -63.826 Z',
		'M 4 -10 L 99.499 -10 A 100 100 0 0 1 4 99.920 L 4 71.826 A 46 46 0 0 0 46 26 L 4 26 Z',
	];
	$idx = [ 'web' => 0, 'consultoria' => 1, 'ia' => 2, 'sistemas' => 3 ];
	$on  = 'oscuro' === $fondo
		? [ 'web' => '#5DBCE9', 'consultoria' => '#3E8FC4', 'ia' => '#ED71A8', 'sistemas' => '#fff' ]
		: [ 'web' => '#5DBCE9', 'consultoria' => '#1F5F8B', 'ia' => '#ED71A8', 'sistemas' => '#18242B' ];
	$off = 'oscuro' === $fondo ? '#2C3A42' : '#DCE3E8';
	$out = '<svg class="' . esc_attr( $clase ) . '" viewBox="-100 -100 200 200" aria-hidden="true">';
	foreach ( $d as $i => $path ) {
		$out .= '<path d="' . $path . '" fill="' . ( $i === $idx[ $k ] ? $on[ $k ] : $off ) . '"/>';
	}
	return $out . '</svg>';
}

function eg_servicios() {
	return [
		'web'         => [ 'nombre' => 'web', 'titulo' => 'Webs y tiendas que se contratan fácil.', 'precio' => 'Desde 1.290 €', 'img' => 'web-s.webp', 'c' => 'var(--eg-web)' ],
		'ia'          => [ 'nombre' => 'ia', 'titulo' => 'La IA, trabajando en tu día a día.', 'precio' => 'Desde 1.490 €', 'img' => 'ia-s.webp', 'c' => 'var(--eg-ia)' ],
		'consultoria' => [ 'nombre' => 'consultoría', 'titulo' => 'Saber por dónde empezar.', 'precio' => 'Diagnóstico, 390 €', 'img' => 'consultoria-s.webp', 'c' => 'var(--eg-con2)' ],
		'sistemas'    => [ 'nombre' => 'sistemas', 'titulo' => 'Software que habla con máquinas.', 'precio' => 'A medida', 'img' => 'sistemas-s.webp', 'c' => '#fff' ],
	];
}

function eg_servicio_url( $k ) {
	return home_url( '/servicios/' . $k . '/' );
}

/** Enlaces del menú principal: los del menú «principal» si existe; si no, los de serie. */
function eg_menu_links() {
	$locs = get_nav_menu_locations();
	if ( ! empty( $locs['principal'] ) ) {
		$items = wp_get_nav_menu_items( $locs['principal'] );
		if ( $items ) {
			$out = [];
			foreach ( $items as $it ) {
				if ( (int) $it->menu_item_parent ) {
					continue;
				}
				$out[] = [ 'url' => $it->url, 'txt' => $it->title, 'dot' => in_array( 'eg-dot', (array) $it->classes, true ) ];
			}
			return $out;
		}
	}
	return [
		[ 'url' => home_url( '/novedades-ia/' ), 'txt' => 'Novedades IA', 'dot' => true ],
		[ 'url' => home_url( '/proyectos/' ), 'txt' => 'Casos', 'dot' => false ],
		[ 'url' => home_url( '/blog/' ), 'txt' => 'Blog', 'dot' => false ],
		[ 'url' => home_url( '/estudio/' ), 'txt' => 'Estudio', 'dot' => false ],
	];
}

/** Redes sociales del pie: [nombre, url, sigla]. Se editan aquí (o con el filtro eg_redes). */
function eg_redes() {
	return apply_filters( 'eg_redes', [] );
}
